//
//  main.m
//  Tarea4DogsMVP
//
//  Created by Patricia Rodriguez Barboza on 3/5/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
