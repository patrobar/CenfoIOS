//
//  DogTableViewCell.m
//  Tarea4DogsMVP
//
//  Created by Patricia Rodriguez Barboza on 3/5/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import "DogTableViewCell.h"
#import "Dog.h"

@interface DogTableViewCell()
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UIImageView *dogImageView;

@end



@implementation DogTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


-(void)setupCellWithDog:(Dog*)dog{
    self.dogImageView.image = [UIImage imageNamed:dog.imageName];
    self.nameLabel.text = dog.name;
}


@end
