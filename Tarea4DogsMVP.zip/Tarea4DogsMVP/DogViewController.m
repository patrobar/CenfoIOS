//
//  DogViewController.m
//  Tarea4DogsMVP
//
//  Created by Patricia Rodriguez Barboza on 3/5/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import "DogViewController.h"
#import "UITableViewCell+GetClassName.h"
#import "UITableView+RegisterCustomCell.h"
#import "Dog.h"
#import "DogTableViewCell.h"
#import "DogDetailsViewController.h"

@interface DogViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (nonatomic,strong) NSMutableArray *dogsArray;


@end

@implementation DogViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableview registerCustomCellWithName:[DogTableViewCell getClassName]];
    [self initializeDogArray];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)initializeDogArray{
    
    Dog *dog1 = [[Dog alloc] initWithName:@"Lucas" imageName:@"1.jpg" color:@"cafe claro" location:@"San Jose" contactinformation:@"Sophia Montero" age:1];
    
    Dog *dog2 = [[Dog alloc] initWithName:@"Copito" imageName:@"2.jpg" color:@"blanco" location:@"Palmares" contactinformation:@"Nicole Rodriguez" age:2];
    
     Dog *dog3 = [[Dog alloc] initWithName:@"Hunnter" imageName:@"3.jpg" color:@"cafe" location:@"Guadalupe" contactinformation:@"Sophia Amador" age:3];
    
    
      Dog *dog4 = [[Dog alloc] initWithName:@"Bolita" imageName:@"4.jpg" color:@"blanco" location:@"Grecia" contactinformation:@"Sonia Barboza" age:1];
    
      Dog *dog5 = [[Dog alloc] initWithName:@"Negra" imageName:@"5.jpg" color:@"cafe" location:@"Guadalupe" contactinformation:@"Sophia Amador" age:3];
    
      Dog *dog6 = [[Dog alloc] initWithName:@"Peluquin" imageName:@"6.jpg" color:@"negro" location:@"Desamparados" contactinformation:@"Marcela Arauz" age:1];
    
      Dog *dog7 = [[Dog alloc] initWithName:@"Ades" imageName:@"7.jpg" color:@"negro" location:@"San Ramon" contactinformation:@"Victoria Moya" age:1];
    
      Dog *dog8 = [[Dog alloc] initWithName:@"Anita" imageName:@"8.jpg" color:@"blanco con negro" location:@"San Carlos" contactinformation:@"Flor Alvarado" age:3];
    
      Dog *dog9 = [[Dog alloc] initWithName:@"Era" imageName:@"9.jpg" color:@"blanco" location:@"Sabanilla" contactinformation:@"Minor Quiros" age:3];
    
      Dog *dog10 = [[Dog alloc] initWithName:@"Valiente" imageName:@"10.jpg" color:@"gris" location:@"San Pedro" contactinformation:@"Roxana Porras" age:3];
    
    self.dogsArray = [[NSMutableArray alloc] initWithObjects:dog1 ,dog2, dog3,dog4,dog5,dog6,dog7,dog8,dog9,dog10,nil];


    
}

#pragma mark - TABLE VIEW DELEGATE
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dogsArray.count;
}



-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    DogTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[DogTableViewCell getClassName]];
    Dog *currentdog = self.dogsArray[indexPath.row];
    [cell setupCellWithDog:currentdog];
    return cell;
}





-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 200;
}



-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    DogDetailsViewController *dogdetailViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"DogDetailsViewController"];
    Dog *dogSelected = self.dogsArray[indexPath.row];
    dogdetailViewController.dogSelected = dogSelected;
    [self.navigationController pushViewController:dogdetailViewController  animated:true];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
