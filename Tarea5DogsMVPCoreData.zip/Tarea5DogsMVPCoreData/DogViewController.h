//
//  DogViewController.h
//  Tarea4DogsMVP
//
//  Created by Patricia Rodriguez Barboza on 3/5/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DogViewController : UIViewController

@end
