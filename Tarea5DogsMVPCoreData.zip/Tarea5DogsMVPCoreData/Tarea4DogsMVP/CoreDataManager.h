//
//  CoreDataManager.h
//  Tarea4DogsMVP
//
//  Created by Patricia Rodriguez Barboza on 3/19/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import <Foundation/Foundation.h>
@class CDDog;


@interface CoreDataManager : NSObject

+(NSArray*)getAllDogs;
+(CDDog*)getDogWithName:(NSString*)dogName;

@end
