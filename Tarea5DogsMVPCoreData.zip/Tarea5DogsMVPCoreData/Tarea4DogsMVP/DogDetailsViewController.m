//
//  DogDetailsViewController.m
//  Tarea4DogsMVP
//
//  Created by Patricia Rodriguez Barboza on 3/5/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import "DogDetailsViewController.h"
#import "CDDog.h"


@interface DogDetailsViewController ()
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UILabel *colorLabel;
@property (weak, nonatomic) IBOutlet UILabel *localidadLabel;
@property (weak, nonatomic) IBOutlet UILabel *edadlabel;
@property (weak, nonatomic) IBOutlet UILabel *contactoLabel;
@property (weak, nonatomic) IBOutlet UIImageView *dogimagen;

@end

@implementation DogDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.nameLabel.text = _dogSelected.name;
    self.colorLabel.text = _dogSelected.color;
    self.localidadLabel.text = _dogSelected.location;
    
    
    NSString *asString = [_dogSelected.age stringValue];
    self.edadlabel.text = asString;
    self.contactoLabel.text = _dogSelected.contactininformation;
  
    NSMutableString* imag = [NSMutableString stringWithString: @"a"];
    [imag appendString: _dogSelected.imageName];
    
     self.dogimagen.image = [UIImage imageNamed:imag];
    

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
