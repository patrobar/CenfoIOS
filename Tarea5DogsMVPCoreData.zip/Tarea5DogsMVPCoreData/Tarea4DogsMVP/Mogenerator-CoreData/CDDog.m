#import "CDDog.h"

@interface CDDog ()

// Private interface goes here.

@end

@implementation CDDog

// Custom logic goes here.

+(id)insertDogWithName:(NSString*)name imageName:(NSString*)imageName color:(NSString*)color location:(NSString*)location contactinformation:(NSString*)contactinformation age:(NSNumber*)age order:(NSInteger)order{
    
    CDDog *dog = [CDDog MR_createEntity];
    
    dog.name = name;
    dog.orderValue = order;
    dog.imageName = imageName;
    
   
    
    dog.color  = color;
    dog.location= location;
    dog.contactininformation= contactinformation;
    dog.age = age;
    
    return dog;
}


@end
