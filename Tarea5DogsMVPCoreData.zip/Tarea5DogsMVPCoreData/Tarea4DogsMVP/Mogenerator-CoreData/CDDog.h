#import "_CDDog.h"
#import <MagicalRecord/MagicalRecord.h>

@interface CDDog : _CDDog
// Custom logic goes here.


+(id)insertDogWithName:(NSString*)name imageName:(NSString*)imageName color:(NSString*)color location:(NSString*)location contactinformation:(NSString*)contactinformation age:(NSNumber*)age order:(NSInteger)order;
@end
