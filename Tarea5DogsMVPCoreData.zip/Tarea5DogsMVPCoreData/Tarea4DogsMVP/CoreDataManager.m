//
//  CoreDataManager.m
//  Tarea4DogsMVP
//
//  Created by Patricia Rodriguez Barboza on 3/19/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import "CoreDataManager.h"
#import <MagicalRecord/MagicalRecord.h>
#import "CDDog.h"

@implementation CoreDataManager


+ (void)saveContext {
    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL contextDidSave, NSError *error) {
        if (contextDidSave) {
            NSLog(@"You successfully saved your context.");
        } else if (error) {
            NSLog(@"Error saving context: %@", error.description);
        }
    }];
}




+(NSArray*)getAllDogs{
    NSArray *dogs = [CDDog MR_findAllSortedBy:@"order" ascending:YES];
    if (dogs.count>0) {
        return dogs;
    }
    return [CoreDataManager insertDogs];
}

+(NSArray*)insertDogs{
    

   [CDDog insertDogWithName:@"Lucas" imageName:@"1.jpg" color:@"cafe claro" location:@"San Jose" contactinformation:@"Sophia Montero" age:[NSNumber numberWithInt:1] order:1];
    

   [CDDog insertDogWithName:@"Copito" imageName:@"2.jpg" color:@"blanco" location:@"Palmares" contactinformation:@"Nicole Rodriguez" age:[NSNumber numberWithInt:2] order:2];
    
  [CDDog insertDogWithName:@"Hunnter" imageName:@"3.jpg" color:@"cafe" location:@"Guadalupe" contactinformation:@"Sophia Amador" age:[NSNumber numberWithInt:3] order:3];
    
  [CDDog insertDogWithName:@"Bolita" imageName:@"4.jpg" color:@"blanco" location:@"Grecia" contactinformation:@"Sonia Barboza" age:[NSNumber numberWithInt:1] order:4];
    
  [CDDog insertDogWithName:@"Negra" imageName:@"5.jpg" color:@"cafe" location:@"Guadalupe" contactinformation:@"Sophia Amador" age:[NSNumber numberWithInt:3] order:5];
    
    
[CDDog insertDogWithName:@"Peluquin" imageName:@"6.jpg" color:@"negro" location:@"Desamparados" contactinformation:@"Marcela Arauz" age:[NSNumber numberWithInt:3] order:6];
    
    
    
    [CDDog insertDogWithName:@"Ades" imageName:@"7.jpg" color:@"negro" location:@"San Ramon" contactinformation:@"Victoria Moya" age:[NSNumber numberWithInt:3] order:7];
    
    [CDDog insertDogWithName:@"Anita" imageName:@"8.jpg" color:@"blanco con negro" location:@"San Carlos" contactinformation:@"Flor Alvarado" age:[NSNumber numberWithInt:3] order:8];
    
    
    [CDDog insertDogWithName:@"Era" imageName:@"9.jpg" color:@"blanco" location:@"Sabanilla" contactinformation:@"Minor Quiros" age:[NSNumber numberWithInt:3] order:9];
    
        [CDDog insertDogWithName:@"Valiente" imageName:@"10.jpg" color:@"gris" location:@"San Pedro" contactinformation:@"Roxana Porras" age:[NSNumber numberWithInt:3] order:10];
    
    [CoreDataManager saveContext];
    return [CoreDataManager getAllDogs];
}




+(CDDog*)getDogWithName:(NSString*)dogName{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name =%@",dogName];
    NSArray *result = [CDDog MR_findAllWithPredicate:predicate];
    if (result.count>0) {
        return result.firstObject;
    }
    return nil;
}



@end
