//
//  Dog.m
//  Tarea4DogsMVP
//
//  Created by Patricia Rodriguez Barboza on 3/5/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import "Dog.h"

@interface  Dog()
@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSString *imageName;
@property (nonatomic,strong) NSString *color;
@property (nonatomic,strong) NSString *location;
@property (nonatomic,strong) NSString *contactinformation;
@property (nonatomic) float age;
@property (nonatomic,strong) NSMutableArray *dogsArray;
@end







@implementation Dog

-(id)initWithName:(NSString*)name imageName:(NSString*)imageName color:(NSString*)color location:(NSString*)location contactinformation:(NSString*)contactinformation age:(float)age{
    if (self = [super init]) {
        _name = name;
        _imageName = imageName;
        
         _color  = color;
         _location= location;
        _contactinformation = contactinformation;
        _age = age;
        
        _dogsArray = [NSMutableArray new];
        
    }
    return self;
}



@end
