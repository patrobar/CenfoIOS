//
//  Dog.h
//  Tarea4DogsMVP
//
//  Created by Patricia Rodriguez Barboza on 3/5/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Dog : NSObject

@property (readonly) NSString *name;
@property (readonly) NSString *imageName;
@property (readonly) NSString *color;
@property (readonly) NSString *location;
@property (readonly) NSString *contactinformation;
@property (readonly) float age;
@property (readonly) NSMutableArray *dogsArray;

-(id)initWithName:(NSString*)name imageName:(NSString*)imageName color:(NSString*)color location:(NSString*)location contactinformation:(NSString*)contactinformation age:(float)age;

@end
