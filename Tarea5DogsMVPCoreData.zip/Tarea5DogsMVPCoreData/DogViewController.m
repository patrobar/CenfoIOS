//
//  DogViewController.m
//  Tarea4DogsMVP
//
//  Created by Patricia Rodriguez Barboza on 3/5/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import "DogViewController.h"
#import "UITableViewCell+GetClassName.h"
#import "UITableView+RegisterCustomCell.h"
#import "CDDog.h"
#import "DogTableViewCell.h"
#import "DogDetailsViewController.h"
#import "CoreDataManager.h"

@interface DogViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (nonatomic,strong)  NSArray  *dogsArray;


@end

@implementation DogViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableview registerCustomCellWithName:[DogTableViewCell getClassName]];
    //[self initializeDogArray];
    self.dogsArray = [CoreDataManager getAllDogs];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




#pragma mark - TABLE VIEW DELEGATE
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dogsArray.count;
}



-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    DogTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:[DogTableViewCell getClassName]];
    CDDog *currentdog = self.dogsArray[indexPath.row];
    [cell setupCellWithDog:currentdog];
    return cell;
}





-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 200;
}



-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    DogDetailsViewController *dogdetailViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"DogDetailsViewController"];
    CDDog *dogSelected = self.dogsArray[indexPath.row];
    dogdetailViewController.dogSelected = dogSelected;
    [self.navigationController pushViewController:dogdetailViewController  animated:true];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
