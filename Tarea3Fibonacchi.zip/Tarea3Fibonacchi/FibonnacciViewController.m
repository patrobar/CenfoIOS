//
//  FibonnacciViewController.m
//  Tarea3Fibonacchi
//
//  Created by Patricia Rodriguez Barboza on 2/26/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import "FibonnacciViewController.h"
#import "FibonnacciTableViewCell.h"

@interface FibonnacciViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableview;


@property (nonatomic,strong) NSMutableArray *dataSource;



@end

@implementation FibonnacciViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self registerCustomCell];
    [self Fibonacci];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




-(void)Fibonacci
{
    int range = 10000;
   
    self.dataSource = [NSMutableArray new];
 
    
    for (int k =0; k< range; k++)
    {
        if(k<2)
        {
                       [self.dataSource addObject:[NSString stringWithFormat:@"%d",k]];
                        continue;
        }
        else
        {
            int fib = [[self.dataSource objectAtIndex:k-2] intValue] + [[self.dataSource objectAtIndex:k-1] intValue];
            [self.dataSource addObject:[NSString stringWithFormat:@"%d",fib]];
           
       }
        
 
        
    }
    
  
   }





-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataSource.count;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    FibonnacciTableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:@"FibonnacciTableViewCell"];
    
    NSString *numbertoDraw = self.dataSource[indexPath.row];
    [cell setupCellWithNumber:numbertoDraw];
    
    
  
    return cell;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 190;
}


-(void)registerCustomCell{
    
    UINib *nib =[UINib nibWithNibName:@"FibonnacciTableViewCell" bundle:nil];
    [self.tableview registerNib:nib forCellReuseIdentifier:@"FibonnacciTableViewCell"];
    
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
