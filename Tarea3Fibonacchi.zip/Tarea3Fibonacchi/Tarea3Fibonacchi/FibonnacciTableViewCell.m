//
//  FibonnacciTableViewCell.m
//  Tarea3Fibonacchi
//
//  Created by Patricia Rodriguez Barboza on 2/26/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import "FibonnacciTableViewCell.h"

@interface FibonnacciTableViewCell()
@property (weak, nonatomic) IBOutlet UILabel *numberLabel;

@end




@implementation FibonnacciTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


-(void)setupCellWithNumber:(NSString*)number {
    self.numberLabel.text=number;
    self.numberLabel.adjustsFontSizeToFitWidth = YES;
}

+(NSString*) getIdentifier {
    
    return NSStringFromClass(self);
    
}



- (void)setFontSize:(NSInteger)size {
  
    UIFont *font = self.numberLabel.font;
    self.numberLabel.font = [font fontWithSize:size];
    //[label setFont: [label.font fontWithSize: sizeYouWant]];    
    //theLabel.minimumFontSize = MIN_FONT_SIZE;nt
}



@end
