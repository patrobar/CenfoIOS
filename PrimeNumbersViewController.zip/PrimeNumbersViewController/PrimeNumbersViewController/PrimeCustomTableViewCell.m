//
//  PrimeCustomTableViewCell.m
//  PrimeNumbersViewController
//
//  Created by Patricia Rodriguez Barboza on 2/18/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import "PrimeCustomTableViewCell.h"


@interface PrimeCustomTableViewCell()
@property (weak, nonatomic) IBOutlet UILabel *primelabel;

@end

@implementation PrimeCustomTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


-(void)setupCellWithNumber:(NSString*)number {
    self.primelabel.text=number;
}


+(NSString*) getIdentifier {
    
    return NSStringFromClass(self);
    
}


@end
