//
//  AppDelegate.h
//  PrimeNumbersViewController
//
//  Created by Patricia Rodriguez Barboza on 2/18/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

