//
//  ViewController.m
//  PrimeNumbersViewController
//
//  Created by Patricia Rodriguez Barboza on 2/18/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import "ViewController.h"
#import "PrimeCustomTableViewCell.h"

@interface ViewController ()

@property (nonatomic,strong) NSMutableArray *dataSource;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
