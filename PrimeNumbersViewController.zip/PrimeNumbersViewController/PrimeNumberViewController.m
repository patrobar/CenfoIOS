//
//  PrimeNumberViewController.m
//  PrimeNumbersViewController
//
//  Created by Patricia Rodriguez Barboza on 2/18/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import "PrimeNumberViewController.h"
#import "PrimeCustomTableViewCell.h"

@interface PrimeNumberViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic,strong) NSMutableArray *dataSource;
@end

@implementation PrimeNumberViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self registerCustomCell];
    [self initializeData];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)initializeData {
    
    self.dataSource = [NSMutableArray new];
    
     [self.dataSource addObject:[NSString stringWithFormat:@"%d",1]];
    for (int j=1;j<=1000;j++){//por definicion el 1 no es primo, se empieza en 2
        int a=0;
        for(int i=1;i<=1000;i++)//divide a j entre los números del 1 al 100
        {
            if(j%i==0) // si num1 módulo de i es 0, incrementamos a en 1.
                a++;
        }
        if (a==2){ //si solo tiene dos números divisores entonces es primo y se imprime
            //printf("%d\n", j);
            [self.dataSource addObject:[NSString stringWithFormat:@"%d",j]];
        }
    
        
    }
    
}








-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataSource.count;
}



-(void)registerCustomCell{
    
    UINib *nib =[UINib nibWithNibName:@"PrimeCustomTableViewCell" bundle:nil];
    [self.tableView registerNib:nib forCellReuseIdentifier:@"PrimeCustomTableViewCell"];
    
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    PrimeCustomTableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:@"PrimeCustomTableViewCell"];
    NSString *numbertoDraw = self.dataSource[indexPath.row];
    [cell setupCellWithNumber:numbertoDraw];
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 100;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
