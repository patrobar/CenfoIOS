//
//  NumbersTableViewController.h
//  Tarea1NumbersTableViewController
//
//  Created by Patricia Rodriguez Barboza on 2/12/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NumbersTableViewController : UITableViewController

@end
