//
//  ViewController.m
//  ClaseQuiz4
//
//  Created by Patricia Rodriguez Barboza on 2/25/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import "ViewController.h"

#import "NumberCustomTableViewCell.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic,strong) NSMutableArray *dataSource;
@property (weak, nonatomic) IBOutlet UITextField *textnumber;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self registerCustomCell];
    //[self initializeData];
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




-(void)initializeData:(NSString*)number  {
    
    self.dataSource = [NSMutableArray new];
    int b = [number intValue];
    int resultado=0;
    for(int index=1; index<11; index++){
       
        resultado = index * b;
            [self.dataSource addObject:[NSString stringWithFormat:@"%d",resultado]];
        
    }
    
    [self.tableView reloadData];// refresca la tabla
    [self.view endEditing:true]; // oculta el teclado
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NumberCustomTableViewCell *cell =[tableView dequeueReusableCellWithIdentifier:@"NumberCustomTableViewCell"];
    NSString *numbertoDraw = self.dataSource[indexPath.row];
    [cell setupCellWithNumber:numbertoDraw];
    return cell;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.dataSource.count;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 150;
}



-(void)registerCustomCell{
    
    UINib *nib =[UINib nibWithNibName:@"NumberCustomTableViewCell" bundle:nil];
    [self.tableView registerNib:nib forCellReuseIdentifier:@"NumberCustomTableViewCell"];
    
}


- (IBAction)buttonCalcular:(UIButton *)sender {
    
    [self initializeData:self.textnumber.text];
    
   
}



@end
