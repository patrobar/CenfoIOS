//
//  NumberCustomTableViewCell.h
//  ClaseQuiz4
//
//  Created by Patricia Rodriguez Barboza on 2/25/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NumberCustomTableViewCell : UITableViewCell

-(void)setupCellWithNumber:(NSString*)number;

+(NSString*) getIdentifier;

@end
