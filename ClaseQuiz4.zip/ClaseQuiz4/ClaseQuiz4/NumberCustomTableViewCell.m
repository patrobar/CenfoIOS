//
//  NumberCustomTableViewCell.m
//  ClaseQuiz4
//
//  Created by Patricia Rodriguez Barboza on 2/25/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import "NumberCustomTableViewCell.h"

@interface NumberCustomTableViewCell()
@property (weak, nonatomic) IBOutlet UILabel *namelabel;
@property (nonatomic,strong) NSMutableArray *dataSource;



@end

@implementation NumberCustomTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


-(void)setupCellWithNumber:(NSString*)number {
    self.namelabel.text=number;
}

+(NSString*) getIdentifier {
    
    return NSStringFromClass(self);
    
}




@end
