//
//  RealmManager.h
//  Tarea4DogsMVP
//
//  Created by Patricia Rodriguez Barboza on 3/12/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import <Foundation/Foundation.h>
#import  <Realm/Realm.h>

@interface RealmManager : NSObject


+(RLMResults*)getAllDog;
+(RLMResults*)getDogWithName:(NSString*)name;

@end
