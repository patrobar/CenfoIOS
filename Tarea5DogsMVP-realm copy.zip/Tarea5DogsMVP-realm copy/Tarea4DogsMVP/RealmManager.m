//
//  RealmManager.m
//  Tarea4DogsMVP
//
//  Created by Patricia Rodriguez Barboza on 3/12/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import "RealmManager.h"
#import "Dog.h"

@implementation RealmManager

+(RLMResults*)getAllDog {
    RLMResults<Dog *> *dogs = [Dog allObjects];
    if(dogs.count > 0){
        return dogs;
    }
    return [RealmManager insertDog];
    
}

+(RLMResults*)insertDog{ //metodo estatico de clase ...
    
    
    Dog *dog1 =   [RealmManager createDogWithName:@"Lucas" imageName:@"1.jpg" color:@"cafe claro" location:@"San Jose" contactinformation:@"Sophia Montero" age:1];
    
    Dog *dog2 =  [RealmManager createDogWithName:@"Copito" imageName:@"2.jpg" color:@"blanco" location:@"Palmares" contactinformation:@"Nicole Rodriguez" age:2];
    
    Dog *dog3 =  [RealmManager createDogWithName:@"Hunnter" imageName:@"3.jpg" color:@"cafe" location:@"Guadalupe" contactinformation:@"Sophia Amador" age:3];
    
    Dog *dog4 =  [RealmManager createDogWithName:@"Bolita" imageName:@"4.jpg" color:@"blanco" location:@"Grecia" contactinformation:@"Sonia Barboza" age:1];
    
    Dog *dog5 =  [RealmManager createDogWithName:@"Negra" imageName:@"5.jpg" color:@"cafe" location:@"Guadalupe" contactinformation:@"Sophia Amador" age:3];
    
    Dog *dog6 =  [RealmManager createDogWithName:@"Peluquin" imageName:@"6.jpg" color:@"negro" location:@"Desamparados" contactinformation:@"Marcela Arauz" age:1];
    
    Dog *dog7 =  [RealmManager createDogWithName:@"Ades" imageName:@"7.jpg" color:@"negro" location:@"San Ramon" contactinformation:@"Victoria Moya" age:1];
    
    Dog *dog8 =  [RealmManager createDogWithName:@"Anita" imageName:@"8.jpg" color:@"blanco con negro" location:@"San Carlos" contactinformation:@"Flor Alvarado" age:3];
    
    Dog *dog9 =  [RealmManager createDogWithName:@"Era" imageName:@"9.jpg" color:@"blanco" location:@"Sabanilla" contactinformation:@"Minor Quiros" age:3];
    
    Dog *dog10 =  [RealmManager createDogWithName:@"Valiente" imageName:@"10.jpg" color:@"gris" location:@"San Pedro" contactinformation:@"Roxana Porras" age:3];
    
    [RealmManager saveRealmObject:dog1];
    [RealmManager saveRealmObject:dog2];
    [RealmManager saveRealmObject:dog3];
    [RealmManager saveRealmObject:dog4];
    [RealmManager saveRealmObject:dog5];
    [RealmManager saveRealmObject:dog6];
    [RealmManager saveRealmObject:dog7];
    [RealmManager saveRealmObject:dog8];
    [RealmManager saveRealmObject:dog9];
    [RealmManager saveRealmObject:dog10];
 
    
    return [RealmManager getAllDog];
    
    
}


//https://realm.io/docs/objc/latest/#nested-objects
+(void)saveRealmObject:(RLMObject*) realmObject {
    // Get the default Realm
    RLMRealm *realm = [RLMRealm defaultRealm];
    // You only need to do this once (per thread)
    // Add to Realm with transaction
    [realm beginWriteTransaction];
    [realm addObject:realmObject ];
    [realm commitWriteTransaction];
}


+(Dog*)createDogWithName:(NSString*)name imageName:(NSString*)imageName color:(NSString*)color location:(NSString*)location contactinformation:(NSString*)contactinformation age:(float)age{
    
    Dog *dog =[[Dog alloc]init];
    dog.name = name;
    dog.imageName = imageName;
     
    dog.color  = color;
      dog.location= location;
      dog.contactinformation = contactinformation;
      dog.age = age;
  
    return dog;
}



+(RLMResults*)getDogWithName:(NSString*)name {
   /* NSPredicate *predicate = [NSPredicate predicateWithFormat:@"name = %@",name];
    RLMResults<Dog *> *dogs=[Dog objectsWithPredicate:predicate];
    if(dogs.count > 0){
        return dogs.firstObject;
    }*/
    return nil;
}




@end
