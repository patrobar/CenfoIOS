//
//  Dog.h
//  Tarea4DogsMVP
//
//  Created by Patricia Rodriguez Barboza on 3/5/17.
//  Copyright © 2017 Patricia Rodriguez Barboza. All rights reserved.
//

#import <Foundation/Foundation.h>
#import  <Realm/Realm.h>

@interface Dog : RLMObject

@property  NSString *name;
@property  NSString *imageName;
@property  NSString *color;
@property  NSString *location;
@property  NSString *contactinformation;
@property  float age;



@end

RLM_ARRAY_TYPE(Dog)
